import boto3
import pandas as pd
import io

def lambda_handler(event, context):
    try:
        s3 = boto3.client('s3')
        bucket = "data15group3-job-data-lake"
        
        # Get all worker results
        all_invalid_jobs = []
        prefix = "temp/worker_results/"
        
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if 'Contents' in response:
            for obj in response['Contents']:
                df = pd.read_parquet(
                    io.BytesIO(
                        s3.get_object(Bucket=bucket, Key=obj['Key'])['Body'].read()
                    )
                )
                all_invalid_jobs.extend(df['job_id'].tolist())

        # Create final invalid jobs CSV and update job_id.csv
        if all_invalid_jobs:
            # Save invalid_jobs.csv
            df_invalid = pd.DataFrame({'job_id': all_invalid_jobs})
            invalid_jobs_key = "raw/invalid_jobs.csv"
            
            csv_buffer = io.StringIO()
            df_invalid.to_csv(csv_buffer, index=False)
            s3.put_object(
                Bucket=bucket,
                Key=invalid_jobs_key,
                Body=csv_buffer.getvalue()
            )
            
            # Update job_id.csv
            response = s3.get_object(Bucket=bucket, Key="raw/job_id.csv")
            df_jobs = pd.read_csv(io.BytesIO(response['Body'].read()))
            
            # Remove invalid jobs
            df_filtered = df_jobs[~df_jobs['job_id'].isin(all_invalid_jobs)]
            
            csv_buffer = io.StringIO()
            df_filtered.to_csv(csv_buffer, index=False)
            s3.put_object(
                Bucket=bucket,
                Key="raw/job_id.csv",
                Body=csv_buffer.getvalue()
            )
            
            print(f"Found {len(all_invalid_jobs)} invalid jobs")
            print(f"Updated job_id.csv: removed {len(all_invalid_jobs)} jobs")
            
        # Delete temp folder and its contents
        temp_files = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if 'Contents' in temp_files:
            for obj in temp_files['Contents']:
                s3.delete_object(Bucket=bucket, Key=obj['Key'])
            print(f"Deleted temp files from {prefix}")
        
        return {
            'statusCode': 200,
            'body': {
                'invalid_jobs_found': len(all_invalid_jobs) if all_invalid_jobs else 0
            }
        }
        
    except Exception as e:
        print(f"Error in collector lambda: {str(e)}")
        raise