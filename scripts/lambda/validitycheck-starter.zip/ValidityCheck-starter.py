import boto3
import pandas as pd
import math
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket = "data15group3-job-data-lake"

    # Delete existing invalid_jobs.csv if it exists
    try:
        s3.delete_object(
            Bucket=bucket,
            Key="raw/invalid_jobs.csv"
        )
        logger.info("Deleted existing invalid_jobs.csv")
    except Exception as e:
        logger.info("No existing invalid_jobs.csv to delete")  
          
    # Read job IDs
    response = s3.get_object(Bucket=bucket, Key="raw/job_id.csv")
    df_jobs = pd.read_csv(response['Body'])
    
    # Calculate number of workers needed
    total_jobs = len(df_jobs)
    JOBS_LIMIT_PER_WORKER = 120
    num_workers = math.ceil(total_jobs / JOBS_LIMIT_PER_WORKER)
    jobs_per_lambda = math.ceil(total_jobs / num_workers)
    
    logger.info(f"Total jobs: {total_jobs}")
    logger.info(f"Number of workers needed: {num_workers}")
    logger.info(f"Jobs per worker: {jobs_per_lambda}")
    
    worker_configs = []
    for i in range(num_workers):
        start_idx = i * jobs_per_lambda
        end_idx = min((i + 1) * jobs_per_lambda, total_jobs)
        worker_configs.append({
            "start_index": start_idx,
            "end_index": end_idx
        })
        logger.info(f"Worker {i}: jobs {start_idx} to {end_idx}")
    
    return {
        "worker_configs": worker_configs,
        "total_jobs": total_jobs,
        "num_workers": num_workers,
        "jobs_per_worker": jobs_per_lambda
    }